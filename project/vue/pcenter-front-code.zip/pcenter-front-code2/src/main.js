// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import FastClick from 'fastclick'
import VueRouter from 'vue-router'
import App from './App'
import store from './store/index'
import routes from './router'
import Vuex from 'vuex'
import axios from '@/util/axios'
import { AlertPlugin, ToastPlugin, LoadingPlugin, ConfirmPlugin, WechatPlugin } from 'vux'
// import http from './libs/http'
// import sess from './libs/sess'
Vue.prototype.$http = axios
Vue.use(VueRouter)
// Vue.prototype.$sess = sess
// Vue.prototype.$http = http
// Vue.prototype.HOST = HOST

// Vue.use(WechatPlugin)
Vue.use(LoadingPlugin)
Vue.use(ToastPlugin)
Vue.use(AlertPlugin)
Vue.use(Vuex)



const router = new VueRouter({
  mode: 'history',
  routes: routes
})

// 不需要登陆的页面 => 白名单
// FastClick.attach(document.body)

Vue.config.productionTip = false



/* eslint-disable no-new */
new Vue({
  store,
  router,
  render: h => h(App)
}).$mount('#index')
