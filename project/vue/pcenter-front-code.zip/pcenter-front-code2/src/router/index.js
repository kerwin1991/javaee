import Vue from 'vue'
import Router from 'vue-router'
import productDetail from '@/components/pcenter/template/product_detail'
import Pbanner from '@/components/pcenter/common/product_banner'
import Pintruction from '@/components/pcenter/common/product_detail_intruction'
import Ptobuy from '@/components/pcenter/common/product_detail_tobuy'
import PolicyWrite from '@/components/pcenter/template/product_policy_write'
import PolicyPreview from '@/components/pcenter/template/product_policy_preview'

Vue.use(Router)
/*
* 1:所有页面的路由配置地方
* 2:所有产品
* 3：
*/
const routes =
  [
	{
	  path: '/',
	  name: '首页',
	  components: {
	    a: Pbanner,
	    c: Pintruction,
	    e: Ptobuy
	  },
	  meta: {
	  	title: '新华保险'
	  }
	},
    {
		path: "/toPolicyWriteq",
		name: "保单填写-模板-通用Aq",
		components: {
		    a: Pbanner
	  	},
		meta: {
			title: "保单"
		}
	},

    {
		path: "/product/pwrite/:productId",
		name: "policywrite",
		components: {
		    main: PolicyWrite
	  	}
	},
    {
    	path: "/product/detail/:productId",
    	name: "产品详情页-不同的产品路由到不同的",
    	components: {
		    main: productDetail
	  	}
    },
    {
    	path: "/product/list",
    	name: "产品列表页",
    	components: {
		    main: productDetail
	  	}
    },
    {
      path: "/product/policy/preview/:productId",
      name: "保单预览",
      components: {
        main: PolicyPreview
      }
    }
  ]

export default routes
