//封装过期控制代码
function set(key,value){
    var curTime = new Date().getTime();
    try{
        localStorage.setItem(key,JSON.stringify({data:value,time:curTime}));
    }catch(oException){
        if(oException.name == 'QuotaExceededError'){
            console.log('已经超出本地存储限定大小！');
                // 可进行超出限定大小之后的操作，如下面可以先清除记录，再次保存
            localStorage.clear();
            localStorage.setItem(key,value);
        }
    }
}

function get(key,exp){
    var data = localStorage.getItem(key);
    var dataObj = JSON.parse(data);
    if (new Date().getTime() - dataObj.time>exp) {
        console.log('信息已过期');
        //alert("信息已过期")
    }else{
        //console.log("data="+dataObj.data);
        //console.log(JSON.parse(dataObj.data));
        var dataObjDatatoJson = JSON.parse(dataObj.data)
        return dataObjDatatoJson;
    }
}

