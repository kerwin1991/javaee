import axios from 'axios'
// import store from '../store'


const service = axios.create({
	timeout:100000
})
// console.log("axios start request..."+service);
service.interceptors.request.use(
	config =>{
		// if(store.state.user.token){
		// 	// config.headers.Authorization = 'token ${store.state.user.token}';
		// 	config.headers.Authorization = 'token token12345';
		// }
		return config ;
	},
	err => {
		return Promise.reject(err);
	}

)

export default service
