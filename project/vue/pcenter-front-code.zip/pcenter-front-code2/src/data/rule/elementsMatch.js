export default ({
  commitMatch : {
    // 投保人属性匹配
    "holderName":"name",
    "holderCardType": "cardType",
    "holderBirthDate": "birthday",
    "holderSex": "sex",
    "holderPhone": "mobile",
    "holderEmail": "email",
    "holderCardNo": "cardNo",
    // 被保人属性匹配
    "insuredName":"name",
    "insuredCardType": "cardType",
    "insuredBirthDate": "birthday",
    "insuredSex": "sex",
    "insuredPhone": "mobile",
    "insuredEmail": "email",
    "insuredCardNo": "cardNo",
    "relation": "insuredRelation",
    // 房屋信息属性匹配
    "cityAddress": "assetAddress",
    "structureType": "assetStrc",
    "cityPicker": ["provinceCode","cityCode","countyCode"],
    "cityNames": ["provinceName","cityName","countyName"],
    // DTO 匹配
    "orderOpenDTO":"orderOpenDTO",
    "productOpenDTO":"productOpenDTO",
    "200000000003":"holderOpenDTO",
    "200000000004":"insuredListOpenDTO",
    "200000000005":"benefitListOpenDTO",
    "200000000006":"assetsOpenDTO",
    // select 值匹配 预览页/确认页 使用
    "holderCardType:1":"身份证",
    "holderCardType:2":"军官证",
    "holderCardType:7":"户口本",
    "holderSex:M":"男",
    "holderSex:F":"女",
    "structureType:1":"钢筋混凝土结构",
    "structureType:3":"混合结构",
    "relation:1":"本人",
    "relation:2":"子女",
    "relation:3":"配偶",
    "relation:7":"其他",
    "relation:10":"父母",
    // 出生日期 FieldId 匹配：投保人holderBirthDate 被保人insuredBirthDate
    "200000000003:birthDate":"holderBirthDate",
    "200000000004:birthDate":"holderBirthDate",
  },
  // 属性正则校验匹配
  validateRuleMatch:{
    "holderNameRule":"nameRule",
    "icardRule":"icardRule",
    "holderPhoneRule":"phoneRule",
    "holderEmaiRule":"emailRule",
    "addressRule":"addressRule",
  }
})
