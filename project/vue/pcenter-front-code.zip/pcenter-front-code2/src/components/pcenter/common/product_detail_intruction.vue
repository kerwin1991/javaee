
  <template>
  	<div style="height:44px;">
  		<sticky     :check-sticky-support='true' >
  			<tab :line-width="1" >
  			  <tab-item @on-item-click="onItemClick" selected>产品介绍</tab-item>
  			  <tab-item @on-item-click="onItemClick" >投保须知</tab-item>
  			  <tab-item @on-item-click="onItemClick" >理赔说明</tab-item>
  			</tab>
  		</sticky>
      <div id="productIntructionTab0" class="prodct_intruction">
           <img width="100%" src="http://uc-cdn01.e-nci.com/images/product/mtwy_cpjs_02-40a2e382bb.png"/>
             <img width="100%" src="http://uc-cdn01.e-nci.com/images/product/mtwy_cpjs_03-fac43fde0b.png"/>
      </div>
      <div id="productIntructionTab1" class="prodct_intruction hideTab">
          <img width="100%" src="http://uc-cdn01.e-nci.com/images/product/lbax_tbxz_01-99d2a7e34a.png">
           
      </div> 
      <div id="productIntructionTab2" class="prodct_intruction hideTab">
           <img width="100%" src="http://uc-cdn01.e-nci.com/images/product/mtwy_cpjs_02-40a2e382bb.png"/>
           <img width="100%" src="http://uc-cdn01.e-nci.com/images/product/mtwy_cpjs_03-fac43fde0b.png"/>
      </div> 
      <!-- <load-more :show-loading="false" tip="别拉了，到底啦"></load-more> -->
  	</div>
  </template>

  <script>
  import { Tab, TabItem, Sticky } from 'vux'
  import $ from 'jquery'
  var productIntructionTab = 0;
  export default {
    components: {
      Tab,
      TabItem,
      Sticky
    },
    props:[
     
    ],
    mounted(){
      // this.initProductIntruction();
    },
    methods:{
      //初始化产品详情信息
      initProductIntruction(){
        //从vuex中获取产品信息
        this.product = this.$store.getters['productDetail/getProduct'];
        
      },
      //详情页-标签-切换事件
      onItemClick(itemIndex){
        $(".prodct_intruction").each(function(index,obj){
            if((index)!=itemIndex){
              $("#productIntructionTab"+index).removeClass('showTab').addClass('hideTab');
            }
        })
        $("#productIntructionTab"+itemIndex).removeClass('hideTab').addClass('showTab');
      }
    },
    data () {
      return {
        product:{}
      }
    }
  }
  </script>
  <style scoped>
    .hideTab {
      display: none
    }
    .showTab {
      display: ''
    }
  </style>