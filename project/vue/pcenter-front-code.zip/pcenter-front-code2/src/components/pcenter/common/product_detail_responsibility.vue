<template>
<div>
    <div>
        <tab selected="index===1"   active-color='#fc378c' v-model="listSkuIndex" >
          <tab-item
                  class="vux-center"
                  :key="item.skucode"
                  @on-item-click="onSkuItemClick(item)"
                  v-for="(item, index) in listSku.skuResList" >
                  {{item.skuInfo}}
          </tab-item>
        </tab>
    </div>
     <div>
        <group v-if="1==1" gutter="0.5rem">
                <div class="weui-cell under_line">
                    <div class="weui-cell_hdv vux-cell-primary self-component-common">保险责任</div>
                    <div class="weui-cell_hd self-component-common">保险金额（元）</div>
                </div>
                <div v-for="(item1, index1) in listSku.skuResList">
                    <div v-for="(calObj,index2) in item1.calComponentResList" >
                        <div  v-for="(calObjDetail,index3) in calObj.calculateInfoList" v-if="listSkuIndex==index1">
                            <cell
                                  class="self-component-common self-detail-res"
                                  is-link
                                  :border-intent="false"
                                  :arrow-direction=" true ? 'up' : 'down'"
                                  @click.native="showOrCloseResRemark(calObjDetail,item1)"
                                  :id= "'resTitle'+calObjDetail.displayElement+''" >

                                  <span style="color: red">{{calObjDetail.defaultVallue}}</span>
                                  <span slot="title" >{{calObjDetail.elementName}}</span>
                            </cell>
                             <p
                                :id= "'resRemark'+calObjDetail.displayElement+''"
                                class="self-res-remark" >{{calObjDetail.remark}}
                             </p>
                        </div>
                    </div>
                </div>
        </group>
    </div>
    <productcalelements  ref="caleles"></productcalelements>
</div>


</template>

<script>
import {Group,Datetime,PopupPicker,Cell,Tab, TabItem, } from 'vux'

import Pcalelements from '@/components/pcenter/common/product_detail_cal'
export default {
  name: 'productresponsibility',
  components: {
    Group,
    Datetime,
    PopupPicker,
    Cell,
    Tab,
    TabItem,
    productcalelements:Pcalelements
  },
  data () {
    return {
      listSku: {},
      listSkuIndex:0,
      title:''
    }
  },
  mounted () {//
    this.initData();
  },
  methods:{
    initData(){
        //【接口】获取试算元素
        this.$http.get('/api/p_front/getCalProductInfo/'+this.$route.params.productId).then(response => {
           this.listSku = response.data;
           this.$refs.caleles.setSkuCode(this.listSku.skuResList[0].skucode);
           this.$refs.caleles.initData(this.listSku.commonResList);
           this.storeCoreProductInfo(this.listSku.skuResList[0]);
        })
    },
    //套餐切换事件
    onSkuItemClick(obj){
//        console.log(obj.skucode)
      this.$refs.caleles.setSkuCode(obj.skucode);
      this.storeCoreProductInfo(obj);
    },
    //险种责任显示/关闭的控制事件
    showOrCloseResRemark(item,obj){
      //显示/关闭-箭头效果控制
      var currentObj = $("#resTitle"+item.displayElement).children().eq(2);
      var preState = currentObj.hasClass("vux-cell-arrow-down");
      $(".vux-cell-arrow-down").removeClass("vux-cell-arrow-down").addClass("vux-cell-arrow-up");
      if(!preState){
        currentObj.removeClass("vux-cell-arrow-up").addClass("vux-cell-arrow-down");
      }
      //显示/关闭-责任效果控制
      var resRemakObj   = $("#resRemark"+item.displayElement);
      var resRemarkList = $(".self-res-remark");
      resRemarkList.each(function(thisIndex,thisObj){
         if(!resRemakObj.hasClass('animate')&&($(thisObj).attr("id")=="resRemark"+item.displayElement)){
            resRemakObj.addClass("animate");
         }else{
            $(thisObj).removeClass("animate");
         }
      })
    },
    storeCoreProductInfo(item){
      this.$store.commit("productDetail/setCoreProduct",item);
    }
  }
}

</script>
<style lang="less" scoped>
  @import '~vux/src/styles/1px.less';
  @import '~vux/src/styles/center.less';
</style>
<style scoped>
    .weui-cells {
      margin-top: 0.5rem !important
    }
    .under_line {
      border-bottom: 1px solid #e8e8ea
    }
    .sub-item {
      color: #888;
    }
    .self-res-remark {
      overflow: hidden ;
      padding: 0 26px;
      font-size: 13px;
      max-height: 0;


    }
    .change-font-size {
      font-size: 13px;
    }
    .animate {
      max-height: 9999px;
      transition-delay: 0s;
    }
    .self-group {
      font-size: 10px;
    }
    .self-component-common {
      font-size: 14px;
    }
    .self-detail-res {
      padding-left: 25px;
      font-size: 13px;
      margin:-5px;
    }
</style>
