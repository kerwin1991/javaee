<!-- 01:输入框 02:下拉框 03: 单选 04:日期插件 10:文本显示值 11:隐藏域 -->
<template>
      <div>
        <group v-if="1==1" gutter="0rem" >
          <!-- 直接显示-保险期间 -->
          <cell

              v-if="benefitPeriodShow"
              class="self-component-common"
              title="保险期间"
              :value="benefitPeriodValue"
              >
          </cell>
          <!-- <input
              type="hidden"
              v-if="item.displayType=='10'"
              :v-on.once="setHiddenProperties(item)"  ></input> -->
          <!-- 下拉选择-保险期间 -->
          <popup-picker
               v-if="benefitPeriodSelectShow"
               title="保险期间"
               class="self-component-common"
               :columns="1"
               :data="benefitPeriodData"
               v-model="benefitPeriodSelectValue"  show-name
               @on-change="benefitPeriodChange"
               :placeholder="'请选择'" >
          </popup-picker>

          <popup-picker
               v-if="employeeCountShow"
               title="雇员人数"
               :readonly="false"
               class="self-component-common"
               :columns="1"
               :data="employeeCountSelectData"
               :v-model="employeeCount"  show-name
               @on-change="employeeCountClick"
               :placeholder="'请选择'" >
          </popup-picker>
          <!-- 时间下拉-保险起期 -->
          <datetime
              v-if="insBeginDateShow"
              title="保险起期"
              :startDate='insBeginDateStartRule'
              :endDate='insBeginDateEndRule'
              class="self-component-common"
              :value="insBeginDate"
              :readonly="false"
              :display-format="startTimeFormat"
              @on-change="startTimeOnChange"
              >
          </datetime>
          <!-- 时间下拉-保险止期-->
          <datetime
              v-if="insEndDateShow"
              title="保险止期"
              :startDate='inEndDateStartRule'
              :endDate='inEndDateEndRule'
              class="self-component-common"
              :value="insEndDate"
              :readonly="false"
              :display-format="endTimeFormat"
              >
          </datetime>
          <cell

              v-if="insEndDateShow_direct"
              class="self-component-common"
              title="保险止期"
              >
              <slot>{{insEndDate}}  24时&nbsp;&nbsp;&nbsp;</slot>
          </cell>
          <!-- 下拉选择-投保份数 -->
          <popup-picker
               v-if="proposalCountShow"
               title="投保份数"
               class="self-component-common"
               :columns="1"
               :data="proposalCountData"
               v-model="proposalCountValue"  show-name
               @on-change="proposalCountChange"
               :placeholder="'请选择'" >
          </popup-picker>
         </group>
         <productDetailFooter ref="tobuy"
                              :insBeginDate="insBeginDate"
                              :insEndDate="insEndDate"
                              :applyNum="proposalCountValue"></productDetailFooter>
  </div>


<!--
  -->


</template>

<script>
import {Group,Datetime,PopupPicker,Cell,Picker} from 'vux'
import Ptobuy from '@/components/pcenter/common/product_detail_tobuy'
// import {format,fromNow} from 'silly-datetime'
// var sd = require('silly-datetime');
var du = require('date-utils');

export default {
  name: 'productcalelements',
  components: {
    productDetailFooter: Ptobuy,
    Group,
    Datetime,
    PopupPicker,
    Cell,
    Picker
  },
  props:[
    'skuCalList'
  ],
  beforeMount:function(){
     // this.insBeginDate = new Date().addDays(1).toFormat("YYYY-MM-DD");
  },
  mounted () {//
    // this.initData();
  },
  data () {
    return {
      title:'',
      //所有的试算要素
      calculateElements:[],
      employeeCountShow:false,
      employeeCount:'',
      employeeCountSelectData:[],

      proposalCountShow:false,
      proposalCountValue:[],
      proposalCount:1,
      proposalCountData:[],

      benefitPeriodUnit:'',
      benefitPeriodUnitValue:'',
      benefitPeriod:'',
      benefitPeriodStart:'',
      benefitPeriodEnd:'',
      benefitPeriodShow:false,
      benefitPeriodSelectShow:false,
      benefitPeriodSelectValue:[],
      benefitPeriodData:[],

      insBeginDateSelectShow:false,
      insBeginDateShow:false,
      insEndDateShow_direct:false,
      insBeginDate:'',
      insEndDateShow:false,
      insEndDate:'',
      insBeginDateStartRule:'',
      insBeginDateEndRule:'',
      inEndDateEndRule:'',
      inEndDateStartRule:'',

      skuCode: ''
    }
  },
  watch: {
    skuCode : function (val,oldVal){
      this.calculatePrenium();
    },
    proposalCount : function(val,oldVal){
      this.calculatePrenium();
       this.composeCalculateData();
    },
    insBeginDate : function(val,oldVal){
       this.insBeginDate = val;
       this.setInsEndDateRange();
    },
    benefitPeriodStart:function(val,oldVal){
       this.setInsEndDateRange();
    },
    benefitPeriodStart:function(val,oldVal){
       this.setInsEndDateRange();
    }
  },
  methods:{
      initData(skuCalList){
          for (var i= 0 ;i<skuCalList.length;i++) {

              var calElement = skuCalList[i] ;
              this.calculateElements[i] = calElement.displayElement;
               //保险期限 （显示值）
               if(calElement.displayType == '10' && calElement.displayElement == 'benefitPeriod' ){
                  this.benefitPeriodShow = true ;
                  this.benefitPeriodStart = calElement.defaultCode;
                  this.benefitPeriodEnd = calElement.defaultCode;
                  this.benefitPeriodValue = calElement.defaultVallue;
               }
               //保险期限 （下拉选择）
               if(calElement.displayType == '02' && calElement.displayElement == 'benefitPeriod' ){
                  this.benefitPeriodSelectShow = true ;
                  this.benefitPeriodData = calElement.availableData;
                  this.benefitPeriodSelectValue = calElement.defaultVallue;
                  this.benefitPeriod = calElement.defaultCode.split("-")[1];
                  this.benefitPeriodStart = calElement.defaultCode.split("-")[0];
                  if(calElement.defaultCode.split("-")[1]==""){//如果不是范围的情况，是固定值则取【0】
                    this.benefitPeriodEnd = calElement.defaultCode.split("-")[0];
                  }else{
                    this.benefitPeriodEnd = calElement.defaultCode.split("-")[1];
                  }
               }
               //保险期限单位
               if(calElement.displayElement == 'benefitPeriodUnit'){
                  this.benefitPeriodUnit = calElement.defaultCode;
               }
               //保险起期 （时间选择框）
               if(calElement.displayType == '04' && calElement.displayElement == 'insBeginDate' ){
                  this.insBeginDateShow = true ;
                  this.setInsBeginDateRange(calElement);
               }
                //保险止期 （时间选择框）calElement.displayType == '04' &&
               if(calElement.displayElement == 'insEndDate' ){
                  if(calElement.displayType == '04'){
                    this.insEndDateShow = true ;
                  }
                  if(calElement.displayType == '10'){
                    this.insEndDateShow_direct = true ;
                  }
                  
                  this.setInsEndDateRange();
               }
               //投保份数-下拉
               if(calElement.displayType == '02' && calElement.displayElement == 'count' ){
                  this.proposalCountShow = true ;
                  this.proposalCountData = JSON.parse(calElement.availableData);
                  this.proposalCountValue = JSON.parse(calElement.defaultVallue);
               }

          }
      },
      calculatePrenium(){
          this.$http.post('http://sitcalculate.e-nci.com/calculatePrenium',
            {
              unioncode: "17112800101",
              productId: "1F3B1FAF2EA8DDA2E0506E0A8701531A",
              skuCode: "1711280010102",
              count:"1"
            }
          ).then(response => {
           this.$refs.tobuy.setPrenium(response.data.prenium);
        })
      },
      composeCalculateData(){//组装试算数据
          let alreadySetCount = 0;
          for(var i = 0 ; i < this.calculateElements.length ; i++){
            var obj = this.calculateElements[i] ;

            //目前先手动判断
            if("benefitPeriod" == obj && '' != this.benefitPeriod){
                alreadySetCount ++ ;
            }
            if("benefitPeriodUnit" == obj && '' != this.benefitPeriodUnit){
                alreadySetCount ++ ;
            }
            if("insBeginDate" == obj && '' != this.insBeginDate){
                alreadySetCount ++ ;
            }
            if("insEndDate" == obj && '' != this.insEndDate){
                alreadySetCount ++ ;
            }
            if("proposalCount" == obj && '' != this.proposalCount){
                alreadySetCount ++ ;
            }

          }

          if(alreadySetCount == this.calculateElements.length){//所有需要的数据不为空的时候，进行试算
                console.log("正在进行试算中...");
          }
      },
      setSkuCode(skuCode){
          this.skuCode = skuCode ;
      },
      setHiddenProperties(obj){
        this.benefitPeriodUnit = obj.code ;
      },
      benefitPeriodOnce(obj){
      },
      benefitPeriodChange(obj){
        this.benefitPeriod = obj[0].split("-")[1];
        this.benefitPeriodStart = obj[0].split("-")[0];
        this.benefitPeriodEnd =  obj[0].split("-")[1];

      },
      setInsBeginDateRange(obj){
        //1:判断起期限制,初始化保险起期开始日期 A:具体的日期数字  A1:代表日期单位
        console.log(obj.checkCondition);
        var checkCondition_startDate = JSON.parse(obj.checkCondition);
        if("" !=  checkCondition_startDate.A && undefined !=  checkCondition_startDate.A){
            if(checkCondition_startDate.A1=='D'){

              var startDateRule_start  = new Date().addDays(parseInt(checkCondition_startDate.A)).toFormat("YYYY-MM-DD");
              
              this.insBeginDateStartRule = startDateRule_start ;
              this.insBeginDate = startDateRule_start ;
            }
        }
        //2:判断保险起期的止期限制，初始化保险起期结束日期 B:代表具体日期 B1:代表日期单位
        if("" !=  checkCondition_startDate.B && undefined !=  checkCondition_startDate.B){
            if(checkCondition_startDate.B1=='D'){
              var startDateRule_end  = new Date().addDays(parseInt(checkCondition_startDate.B)).toFormat("YYYY-MM-DD");
              this.insBeginDateEndRule = startDateRule_end;

            }
        }

      },
      setInsEndDateRange(){
        //当保险期限为空的时候默认为 起期
        if("" == this.benefitPeriodStart){
           this.insEndDate = this.insBeginDate ;
        }else{
          //判断保险期限单位
          var plusDate = 0 ;
          if('2' == this.benefitPeriodUnit){
              var startDateRule  = new Date(this.insBeginDate)
                                       .addYears(parseInt(this.benefitPeriodStart))
                                       .removeDays(1).toFormat("YYYY-MM-DD");
              var endDateRule    = new Date(this.insBeginDate)
                                       .addYears(parseInt(this.benefitPeriodEnd))
                                       .removeDays(1).toFormat("YYYY-MM-DD");

              this.inEndDateEndRule = endDateRule;
              this.inEndDateStartRule= startDateRule;
              this.insEndDate = endDateRule;
          }else if('5' == this.benefitPeriodUnit){
              var startDateRule  = new Date(this.insBeginDate)
                                       .addDays(parseInt(this.benefitPeriodStart))
                                       .removeDays(1).toFormat("YYYY-MM-DD");
              var endDateRule  = new Date(this.insBeginDate)
                                       .addDays(parseInt(this.benefitPeriodEnd))
                                       .removeDays(1).toFormat("YYYY-MM-DD");
              this.inEndDateEndRule = endDateRule;
              this.inEndDateStartRule = startDateRule;
              this.insEndDate = endDateRule;
          }
        }
      },
      employeeCountClick(count){

      },
      proposalCountChange(count){
        this.proposalCount = count ;
      },
      startTimeFormat(insBeginDate){
        this.insBeginDate = insBeginDate ;
        return insBeginDate + " 零时";
      },
      startTimeOnChange(newDate){
        this.insBeginDate = newDate ;
      },
      setStartTimeOnShow(obj){
         this.insBeginDateStartRule = '2018-12-09';
         this.insBeginDateEndRule = '2018-12-12';
      },

      setEndTimeRange(startTime,endTime){
        this.inEndDateEndRule = startTime ;
        this.inEndDateStartRule = endTime ;
      },
      endTimeFormat(insEndDate){
        this.insEndDate = insEndDate ;
        return insEndDate + " 24时";
      },
      endTimeOnChange(insEndDate){

      }
  }
}

</script>

<style scoped>
.self-component-common {
  font-size: 14px;
}
</style>
