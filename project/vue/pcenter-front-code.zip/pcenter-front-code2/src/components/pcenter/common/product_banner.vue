
<template>
	<div class="banner">
		<x-header
     :title="productName"
     :left-options="leftOoptions"
     :right-options="rightOoptions"
     left-options.showBack=true
     ></x-header>
		<swiper id="banner" :list="bannerinfo" ></swiper>
	</div>
</template>

<script>
import { XHeader, Swiper } from 'vux'

export default {
  name: 'productbanner',
  components: {
    XHeader,
    Swiper
  },
  props: [
    // 'productInfo'
  ],

  data () {
    return {
      title : '',
      productName:'',
      leftOoptions :  {showBack: false},
      rightOoptions : {showMore: false},
      bannerinfo : [],
      product : {name:''}
    }
  },
  watch : {
    title : function(newVal,oldVal){
      if(undefined != newVal){
         document.title= newVal ;
      }
    }
  },
  mounted(){
    // this.initBannerList();
  },
  methods : {
    initBannerList(data){
      //从vuex中获取产品信息
      this.product = this.$store.getters['productDetail/getProduct'];
      console.log("00000"+this.product);
      if(undefined!=this.product){
          this.reBuildBannerListByProduct();
          this.title = this.product.title;
          this.productName = this.product.title;
          console.log(this.productName);
      }
    },
    //重新组装banner数据，根据产品信息
    reBuildBannerListByProduct(){
      console.log("222"+this.product.title);
      this.bannerinfo = [{
        url : 'javascript:',
        img :   this.product.bannerimg,
        title : this.product.introduction
      }]
       
    }
  }
}

</script>
.vux-header .vux-header-title, .vux-header h1
<style lang="less">
  .banner{
    
    .vux-header h1{
      font-size:15px;
    }
  }

</style>