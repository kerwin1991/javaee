<template>
  <div class="m-tabbar" style="height: 100%">
      <tabbar >
        <tabbar-item>
          <span slot="label" :v-text="prenium">￥{{prenium}}元</span>
        </tabbar-item>
         <tabbar-item>
          <span slot="label">分享</span>
        </tabbar-item>
         <tabbar-item>
          <span slot="label" @click="goBuy()"><div>立即购买</div></span>
        </tabbar-item>
    </tabbar>
  </div>
</template>
<script>
import { XButton ,Tabbar, TabbarItem, Alert} from 'vux'

export default {
  components: {
    XButton,
    Tabbar,
    TabbarItem,
    Alert
  },
  methods:{
    setPrenium(prenium){
      this.$vux.loading.show();
      this.prenium = prenium;
      this.$vux.loading.hide();
    },
    goBuy(){
      if(this.checkGoBuy()){
        this.$http.post('/api/p_front/order/makeOrder',
          {
            calculateCalReqOpenDTO: {
              age: this.age,
              benefitPeriod: this.benefitPeriod,
              benefitPeriodUnit: this.benefitPeriodUnit,
              count: this.applyNum[0],
              skuCode: this.$store.state.productDetail.coreProduct.skucode
            },
            orderOpenDTO: {
              insBeginDate: this.insBeginDate,
              insEndDate: this.insEndDate,
              insPeriod: this.insPeriod,
              policySource: this.policySource,
              refereeid: "3689702008174022656",
              totalApplyNum: this.applyNum[0],
              totalPremium: (this.prenium * this.applyNum[0])
            },
            productOpenDTO: {
              applyNum: this.applyNum[0],
              coreProductId: this.$store.state.productDetail.coreProduct.productId,
              numOfPeople: 0,
              partnerProductId: this.$store.state.productDetail.product.productId,
              premium: this.prenium,
              productCode: this.$store.state.productDetail.coreProduct.skucode,
              unionCode: this.$store.state.productDetail.product.code
            }
          }
        ).then(response => {
          //判断返回状态是否正确进行跳转
          this.$store.commit("productDetail/setOrderInfos", response.data);
          this.$router.push({path:'/product/pwrite/'+this.$route.params.productId});
        })
      }
      // test code
      //this.$router.push({path:'/product/pwrite/'+this.$route.params.productId});
      // test code
    },
    checkGoBuy(){
      // 判断金额不能为空
      if(this.prenium == '0.00'){
          this.$vux.toast.text('保费正在计算中,请稍后...', 'middle');
          return false;
      }
      return true ;
    }
  },
  data () {
    return {
      demo01_list: 1236,
      prenium:'0.00',
      age: 0,
      benefitPeriod: "1",
      benefitPeriodUnit: "Y",
      skuCode: "",
      insPeriod: "7",
      policySource: "D888",
      refereeid: "3689702008174022656",
      totalPremium: 0,
      numOfPeople: 0,
    }
  },
  props:[
    "insBeginDate","insEndDate","applyNum",
  ],
}
</script>
<style lang="less">
.m-tabbar{
    .weui-tabbar{
      position: fixed;
      a{
        &:nth-of-type(1){
          background-color: white;
          span{
            font-size: 18px;
            color:red;
          }
        }
        &:nth-of-type(2){
          background-color: #43b0f1;
          span{
            font-size: 18px;
            color:white;
          }
        }
        &:nth-of-type(3){
          background-color: #ff5a00;
          span{
            font-size: 18px;
            color:white;
          }
        }
      }
  }
}
</style>

