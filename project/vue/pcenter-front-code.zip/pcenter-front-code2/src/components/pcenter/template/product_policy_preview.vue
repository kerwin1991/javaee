<template>
  <div>
    <x-header :left-options="{backText: ''}">保单预览</x-header>
    <group v-for="(item,index0) in bindData" :title = "item.moduleName" title-color = "#43b0f1"
           label-width="5em" label-margin-right="3em" label-align="left">
      <template v-for="(eleItem,index1) in bindData[index0].elementOpenDTOList" >
        <!-- 输入框 -->
        <x-input
          :title="eleItem.elementName"
          :placeholder='eleItem.fieldPlaceholder' placeholder-align='left'
          v-model="bindData[index0].elementOpenDTOList[index1].fieldDefaultValue"
          disabled>
        </x-input>
        <!--<cell :title="eleItem.elementName" :value="bindData[index0].elementOpenDTOList[index1].fieldDefaultValue"></cell>-->
      </template>
    </group>
    <div v-show="showButton">
      <check-icon :value.sync="checkVal" style="height: 40px;" type="plain"></check-icon>
      <span style="font-size:13px">我已阅读并同意<a class="agree" href="http://www.baidu.com">《保险条款》</a>及<a class="agree" href="http://www.csdn.net">《投保提示》</a></span>
      <x-button :text="submitButtonValue"  @click.native="payCommit" type="primary" :disabled="!checkVal"></x-button>
    </div>
    <a v-show="false" :href="payPage"><span id="pay">pay</span></a>
  </div>
</template>

<script>
  import { CheckIcon, XButton, XHeader, GroupTitle, Group, Cell, XInput } from 'vux'
  import elementsMatch from '@/data/rule/elementsMatch'
  export default{
    components: {
      CheckIcon,XButton,XHeader,GroupTitle,Group,Cell,XInput
    },
    data(){
      return{
        bindData:[],
        queryData:{},
        submitButtonValue:"¥0.00立即支付",
        showButton:false,
        isClick:true,
        checkVal:false,
        payPage:'',
        dtoIds:{}
      }
    },
    methods:{
      // 将默认值，改为查询值 dto-->modual
      changeDefaultVal(moduleOpenDTOList){
        let match = elementsMatch.commitMatch;
        // 第一个被保人
        let insuredCount = 0;
        let idx0;
        for(idx0=0; idx0<moduleOpenDTOList.length; idx0++){
          let moduleOpenDTO = moduleOpenDTOList[idx0];
          let emptyCount = 0;
          let dtoKey = match[moduleOpenDTO.moduleCode];
          let dtoVal = this.queryData[dtoKey];
          if("200000000004" == moduleOpenDTO.moduleCode){
            dtoVal = dtoVal.insuredDTOList;
            if(dtoVal && Array.isArray(dtoVal) && dtoVal.length > insuredCount) {
              dtoVal = dtoVal[insuredCount];
              insuredCount++;
            }else{
              dtoVal = null;
            }
          }
          if(!dtoVal) return;

          this.storeDTOId(moduleOpenDTO.moduleCode, dtoVal.id);
          let idx1;
          for (idx1=0; idx1<moduleOpenDTO.elementOpenDTOList.length; idx1++){
            let elementOpenDTO = moduleOpenDTO.elementOpenDTOList[idx1];
            let val = dtoVal[match[elementOpenDTO.elementFieldId]];
            if ('02' == elementOpenDTO.elementFieldType){
              elementOpenDTO.fieldDefaultValue = match[elementOpenDTO.elementFieldId + ":" + val];
            } else if('05' == elementOpenDTO.elementFieldType) {
              elementOpenDTO.fieldDefaultValue = dtoVal.provinceName + " " + dtoVal.cityName + " " + dtoVal.countyName;
            } else {
              elementOpenDTO.fieldDefaultValue = val;
            }
            // 最后某元素值为空，删除
            if(!elementOpenDTO.fieldDefaultValue){
              moduleOpenDTO.elementOpenDTOList.splice(idx1, 1);
              emptyCount++;
              idx1--;
            }
          }

          console.info(idx0, emptyCount, moduleOpenDTO.elementOpenDTOList.length);
          if(moduleOpenDTO.elementOpenDTOList.length == 0){
            moduleOpenDTOList.splice(idx0, 1);
            idx0--;
          }
        }
      },
      // 请求预览页需要加载的元素
      queryShowElements(){
        this.$http.get('/api/p_front/cms/product/policyElemenets/'+this.$route.params.productId+'/01').then(response => {
          this.policyTemplateEle = response.data.templetOpenDTO;
          this.changeDefaultVal(this.policyTemplateEle.moduleOpenDTOList);
          this.bindData = this.policyTemplateEle.moduleOpenDTOList;
          //console.info(JSON.stringify(this.bindData))
          this.showButton = true;
        })
      },
      payCommit(){
        console.info("立即支付。。。");
        let reqParam = {policyId:this.$store.getters['productDetail/getPolicyId']};
        this.$http.post('/api/p_front/insurance/proposal/verifyProposal', reqParam).then(response => {
          //console.info(response.data);
          if(response.data.isSuccess == 'Y'){
            this.payPage = response.data.payPageUrl;
          }else{
            console.info("核保失败");
          }
        });
      },
      storeDTOId(moduleCode,id){
        let dtoId = this.dtoIds[moduleCode];
        if(!dtoId) this.dtoIds[moduleCode] = id
        else if (Array.isArray(dtoId)) this.dtoIds[moduleCode].push(id)
        else this.dtoIds[moduleCode] = [dtoId,id]
      }
    },
    mounted(){
      // 请求预览页dto信息
      let queryParam = {
       queryType:'00',
       orderOpenDTO:this.orderInfos
//       orderOpenDTO:{orderId:"b7269100415a41e4867ceca2bf765225",policyId:"6c650b96faeb4148842b294794023bb5"}
      };
      this.$http.post('/api/p_front/insurance/proposal/queryProposal', queryParam).then(response => {
        if(response.data.rspCode == "FI00000" && response.data.holderOpenDTO) {
          this.queryData = response.data;
          this.submitButtonValue = this.submitButtonValue.replace('0.00', this.queryData.policyOpenDTO.premium);
          this.queryShowElements();
        }else{
          console.info(`查询保单失败：${response.data.rspMsg}`);
        }
      })
      // test code
      /*this.$http.get('/api/p_front/product/policy/query').then(response => {
        if(response.data.rspCode == "FI00000") {
          this.queryData = response.data;
          this.submitButtonValue = this.submitButtonValue.replace('0.00', this.queryData.policyOpenDTO.premium);
          this.queryShowElements();
        }
      })*/
    },
    computed:{
      orderInfos(){
        return this.$store.state.productDetail.orderInfos;
      },
    },
    watch: {
      payPage:{
        deep: true, //深度监听
        handler: function (newVal,oldVal) {
          if(newVal) {
            setTimeout(()=>{
              $("#pay").trigger("click");
            }, 100);
          }
        }
      }
    },
  }
</script>
<style>
  .agree{
    color: #0066FF;
  }
</style>
