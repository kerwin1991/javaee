<template>
 <div style="height: 100%">
        <!-- Banner信息 -->
 		    <banner  ref="banner"></banner>
        <!-- 产品责任和产品试算项信息 -->
        <productPonsibility></productPonsibility>
        <!-- 产品详情信息 -->
        <productIntruction ref="productIntruction"></productIntruction>
  </div>
</template>
<script>

import { XButton,Divider, PopupPicker, Cell, CellBox, CellFormPreview, Group, Badge,
         Tab, TabItem, Datetime, Swiper, SwiperItem, InlineXNumber } from 'vux'
import $ from 'jquery'
import Pbanner from '@/components/pcenter/common/product_banner'
import productIntruction from '@/components/pcenter/common/product_detail_intruction'
import productPonsibility from '@/components/pcenter/common/product_detail_responsibility'

//此处进行ajax请求，获取产品信息
export default {
  components: {
    XButton,Divider,PopupPicker,Cell,CellBox,CellFormPreview,Group,Badge,Tab,
    TabItem,Datetime,Swiper,SwiperItem,InlineXNumber,
    banner: Pbanner, productPonsibility: productPonsibility, productIntruction: productIntruction
  },
  created(){

  },
  mounted () {
    this.initData();
  },
  data () {
    return { }
  },
  methods:{
    //初始化试算页数据
    initData(){
      // 使用方式不对删除-XXXXXX
      this.$store.commit("policyWrite/removePolicyWriteData",null);
       //通过接口获取产品信息 GET
      this.$http.get('/api/p_front/getCmsProduct/'+this.$route.params.productId).then(response => {
          //存储产品信息到Vuex中

          this.$store.commit("productDetail/setProduct",response.data);
          //放里面，加载顺序不会有问题
          this.$refs.banner.initBannerList();//初始化Banner信息
          this.$refs.productIntruction.initProductIntruction();// //初始化产品详情信息
      })
      //

    }
  }
}
</script>

<style lang="less" scoped>
  @import '~vux/src/styles/1px.less';
  @import '~vux/src/styles/center.less';
</style>

<style scoped>
  .self-component-common {
    font-size: 14px;
  }
</style>
