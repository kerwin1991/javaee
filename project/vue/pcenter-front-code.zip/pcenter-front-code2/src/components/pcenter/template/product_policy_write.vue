<template>
<div >
    <x-header :left-options="{backText: ''}">华华惠满家综合保障计划</x-header>
      <group v-for="(item,index0) in bindData" :title = "item.moduleName" title-color = "#43b0f1"
                label-width="5em" label-margin-right="1em" label-align="left">

             <template v-for="(eleItem,index1) in bindData[index0].elementOpenDTOList" >
                    <!-- 输入框 -->
                    <x-input
                        :title="eleItem.elementName"
                        :placeholder='eleItem.fieldPlaceholder' placeholder-align='left'
                        v-model="bindData[index0].elementOpenDTOList[index1].fieldDefaultValue"
                        v-if="eleItem.elementFieldType == '01'" @on-blur="blurValidate(index0,index1)">
                    </x-input>
                    <x-input
                        :title="eleItem.elementName"
                        :placeholder='eleItem.fieldPlaceholder' placeholder-align='left'
                        v-model="bindData[index0].elementOpenDTOList[index1].fieldSelectValues"
                        v-else-if="eleItem.elementFieldType == '10'" readonly>
                    </x-input>
                    <!-- 下拉框 -->
                    <popup-picker
                        :title="eleItem.elementName"  :placeholder="eleItem.fieldPlaceholder"
                        v-model="bindData[index0].elementOpenDTOList[index1].fieldDefaultValue"
                        value-text-align="left"  show-name :columns="1"
                        v-else-if="eleItem.elementFieldType == '02'"
                        :data="formatData(eleItem.fieldSelectValues)" @on-change="selectChange(index0,index1)">
                    </popup-picker>
                    <!--日期-->
                    <datetime
                        :title="eleItem.elementName" v-else-if="eleItem.elementFieldType == '04'"
                        v-model="bindData[index0].elementOpenDTOList[index1].fieldDefaultValue"
                        value-text-align="left" :placeholder='eleItem.fieldPlaceholder' :min-year="defaultYear"
                        confirm-text="确认" cancel-text="取消" @on-cancel="selectValidate(index0,index1)">
                    </datetime>
                    <x-address
                      title="所在城市" raw-value :list="cityPicker" value-text-align="left"
                      label-align="justify" v-else-if="eleItem.elementFieldType == '05'"
                      v-model="bindData[index0].elementOpenDTOList[index1].fieldDefaultValue"
                      @on-hide="selectValidate(index0,index1)" @on-shadow-change="cityNameChange">
                    </x-address>
              </template>
      </group>
    <!--警告框-->
    <toast v-model="showPositionValue" type="text" width="15em" :time="2500" is-show-mask :text="alertContent" :position="position"></toast>
    <x-button :text="submitButtonValue"  @click.native="processButton001" type="primary"></x-button>

</div>
</template>
<script>
import { XButton, XHeader, GroupTitle, Group, Cell, XInput, Selector, PopupPicker, Datetime, XNumber, ChinaAddressData, XAddress, XTextarea, XSwitch, Toast } from 'vux'
import storage from '@/util/storage'
import elementsMatch from '@/data/rule/elementsMatch'
import regcheck from '@/data/rule/regcheck'

export default {
  components: {
    XButton,XHeader,GroupTitle,Group,Cell,XInput,Selector,PopupPicker,Datetime,XNumber,
    ChinaAddressData,XAddress,XTextarea,XSwitch,Toast
  },
  methods:{

    holderSex(abc,rr){
      console.log(123);
    },
    formatData1(val){
      console.log(1111111111);
      var arr = eval ("(" + val+ ")");
      // var returnArray = new Array();
      // for(var i = 0 ; i < arr.length ; i++){
      //   var jsonObj = {};
      //   jsonObj.name= "1";
      //   jsonObj.value= "2";
      //   returnArray.push(jsonObj);
      //   console.log(jsonObj);
      // }
      // console.log(returnArray);

      return ['F'];
    },
    formatData(val){
      var arr = eval ("(" + val+ ")");
      return arr;
    },
    commitValidate(){
      for(let moduleOpenDTO of this.bindData) {
        let moduleName = this.getModuleNameForAlert(moduleOpenDTO.moduleName);
        for(let element of moduleOpenDTO.elementOpenDTOList){
          if("05" == element.elementFieldType && element.fieldDefaultValue.length==0)
            return this.getAlertMsg(moduleName,element.elementName);
          // 判断是否提交校验
          if ('Y' == element.fieldBoocheck) {
            let result = true;
            let ruleCheck = JSON.parse(element.fieldCheckRule || "null");
            if (!ruleCheck){
              // 不需要匹配正则 判空
              result = !!element.fieldDefaultValue;
            }else{
              // 需要匹配正则
              result = this.validateVal(element, ruleCheck.rule);
            }
            if(!result)
              return this.getAlertMsg(moduleName,element.elementName);
          }
        }
      }
      return "";
    },
    // 组装dtoValue
    assembleDTOValue(elementOpenDTOList){
      let dtoValue = {};
      elementOpenDTOList.forEach((elementOpenDTO) => {
        // 单独处理所在城市
        if("05" == elementOpenDTO.elementFieldType) {
          let cityKeys = this.policyCommitMatch[elementOpenDTO.elementFieldId];
          let cityNameKeys = this.policyCommitMatch.cityNames;
          if(!cityKeys || cityKeys.length!=3) return;
          //console.info("所在城市：",elementOpenDTO.fieldDefaultValue)
          dtoValue[cityKeys[0]] = elementOpenDTO.fieldDefaultValue[0];
          dtoValue[cityKeys[1]] = elementOpenDTO.fieldDefaultValue[1];
          dtoValue[cityKeys[2]] = elementOpenDTO.fieldDefaultValue[2];
          dtoValue[cityNameKeys[0]] = this.cityNames[0];
          dtoValue[cityNameKeys[1]] = this.cityNames[1];
          dtoValue[cityNameKeys[2]] = this.cityNames[2];
          elementOpenDTO.fieldDefaultValue = []; // 置空 防止返回报错
          return;
        }
        let childDtoKey = this.policyCommitMatch[elementOpenDTO.elementFieldId];
        if (!childDtoKey || !elementOpenDTO.fieldDefaultValue) return;
        if (Array.isArray(elementOpenDTO.fieldDefaultValue)) {
          dtoValue[childDtoKey] = elementOpenDTO.fieldDefaultValue[0];
        } else {
          dtoValue[childDtoKey] = elementOpenDTO.fieldDefaultValue;
        }
      });
      return dtoValue;
    },
    //
    processButton001(){
      // 提交 校验
      let msg = this.commitValidate();
      if(!!msg) {
        this.showAlert(msg);
        console.error("提交校验完毕，警告提示：",msg);
        return;
      }
      console.info("提交前校验全部OK!  ".repeat(2));
      // 组装请求更新保单报文
      let insuredDTOValue = {insuredDTOList:[]};
      let reqParams = {};
      this.bindData.forEach((moduleOpenDTO) => {
        let dtoKey = this.policyCommitMatch[moduleOpenDTO.moduleCode];
        let dtoValue = this.assembleDTOValue(moduleOpenDTO.elementOpenDTOList);
        if(Object.keys(dtoValue).length == 0) return;
        if("200000000004" == moduleOpenDTO.moduleCode){
          console.info("被保人类型：",dtoValue.insuredRelation);
          // 如果是本人，携带投保人信息到被保人列表
          if("1" == dtoValue.insuredRelation) {
            dtoValue = Object.assign(dtoValue, reqParams.holderOpenDTO);
          }
          insuredDTOValue.insuredDTOList.push(dtoValue);
          reqParams[dtoKey] = insuredDTOValue;
        }else{
          reqParams[dtoKey] = dtoValue;
        }
      });
      // 缓存提交数据
      this.$store.commit("policyWrite/storePolicyWriteData",this.bindData);
      // 发送请求更新保单
      reqParams[this.policyCommitMatch["orderOpenDTO"]] = this.$store.state.productDetail.orderInfos;
      reqParams[this.policyCommitMatch["productOpenDTO"]] = {"productCode":this.$store.getters['productDetail/getSkucode']};
      console.info(JSON.stringify(reqParams));
      this.$http.post('/api/p_front/insurance/proposal/updateProposal',reqParams).then(response => {
        if("FI00000" != response.data.rspCode){
          console.info("更新保单失败：" + response.data.rspMsg);
          //alert("更新保单失败：" + response.data.rspMsg);
          //location.reload(true);
        }else{
          // 更新成功后，跳转到保单预览页面
          this.$router.push({path:'/product/policy/preview/'+this.$route.params.productId});
        }
      });
    },
    // 支持PopupPicker插件中数组类型属性，字符串转为数组对象
    stringToArray(moduleOpenDTOList){
      moduleOpenDTOList.forEach((moduleOpenDTO,idx0)=>{
        moduleOpenDTO.elementOpenDTOList.forEach((elementOpenDTO)=>{
          if ('02' == elementOpenDTO.elementFieldType)
            elementOpenDTO.fieldDefaultValue = JSON.parse(elementOpenDTO.fieldDefaultValue);
          else if('05' == elementOpenDTO.elementFieldType)
            elementOpenDTO.fieldDefaultValue = [];
        });
        // 此处记录，只支持一个被保人，如需增加需要改动
        if("200000000004" == moduleOpenDTO.moduleCode){
          // 记录被保人的module索引
          this.insuredIndex = idx0;
          console.info(this.insuredIndex);
          let [element0,...elements] = [...moduleOpenDTO.elementOpenDTOList];
          moduleOpenDTO.elementOpenDTOList = [element0];
          // 记录被保人需要填写的元素
          this.insuredElements = elements;
        }
      });
    },
    // 获取属性匹配json
    getElementsMatch(){
      this.policyCommitMatch = elementsMatch.commitMatch;
    },
    // 显示警告框
    showAlert(msg){
      this.alertContent = msg;
      this.showPositionValue = true;
    },
    // 匹配正则，返回boolean校验结果，false 校验失败
    validateVal(element,ruleName){
      let regKey = elementsMatch.validateRuleMatch[ruleName];
      if(!regKey){
        console.info("没有匹配到可用的正则");
        return;
      }else{
        console.info(`匹配到可用的正则:${regKey}`);
      }
      return new RegExp(regcheck[regKey]).test(element.fieldDefaultValue);
    },
    // blur校验
    blurValidate(index0,index1){
      let element = this.bindData[index0].elementOpenDTOList[index1];
      let moduleName = this.getModuleNameForAlert(this.bindData[index0].moduleName);
      if('Y' != element.fieldBlurcheck || !element.fieldDefaultValue) return;
      let ruleName = null;
      try {
        ruleName = JSON.parse(element.fieldCheckRule).rule;
      }catch(err){
        console.info(err.message);
        if('300000017' == element.elementCode) {
          let elementType = this.bindData[index0].elementOpenDTOList[index1-1];
          console.info("证件类型："+elementType.fieldDefaultValue[0]);
          if(1 == elementType.fieldDefaultValue[0]) ruleName = 'icardRule';
        }
      }
      if(!ruleName) return;
      let ret = this.validateVal(element,ruleName);
      if(!ret) this.showAlert(this.getAlertMsg(moduleName, element.elementName));
      else if('300000017' == element.elementCode) {
        this.cardNoCarryBirth(element.fieldDefaultValue, this.bindData[index0].moduleCode,index0);
      }
    },
    // 校验列表
    selectValidate(index0,index1){
      let element = this.bindData[index0].elementOpenDTOList[index1];
      let moduleName = this.getModuleNameForAlert(this.bindData[index0].moduleName);
      let val = element.fieldDefaultValue;
      if(Array.isArray(val) ? !val.length : !val)
        this.showAlert(this.getAlertMsg(moduleName, element.elementName));
    },
    // 根据 elementFieldId 从bindData查找 指定module：idx0下元素 返回 [index0,index1]
    getElementByFieldId(fieldId,idx0){
      // if(!fieldId) return;
      if(!fieldId) fieldId = "holderBirthDate"; // test code
      for([index0, moduleOpenDTO] of this.bindData.entries()){
        console.info("cha",idx0, index0);
        if (index0 != idx0) continue;
        for([index1, elementOpenDTO] of moduleOpenDTO.elementOpenDTOList.entries()){
          if (fieldId == elementOpenDTO.elementFieldId){
            console.info("返回",index0, index1);
            return [index0, index1];
          }
        }
      }
      return null;
    },
    // 携带出生日期
    cardNoCarryBirth(cardNo,moduleCode,index0){
      let fieldId = this.policyCommitMatch[`${moduleCode}:birthDate`];
      let retIndex = this.getElementByFieldId(fieldId,index0);
      if(!retIndex) return;
      console.info("ret",retIndex);
      let birth = cardNo.substring(6, 10) + "-" + cardNo.substring(10, 12) + "-" + cardNo.substring(12, 14);
      this.bindData[retIndex[0]].elementOpenDTOList[retIndex[1]].fieldDefaultValue = birth;
    },
    // popup-picker 值改变事件 '为谁投保' 下拉框值改变事件
    selectChange(idx0,idx1){
      if(this.insuredIndex != idx0) return;
      let element = this.bindData[idx0].elementOpenDTOList[idx1];
      if("300000010"!=element.elementCode) return;
      // 判断为谁投保 1 : 为本人
      console.info("为谁投保："+element.fieldDefaultValue[0]);
      // 被保人模块，留下第一个元素，移除或显示其它元素
      if(1 == element.fieldDefaultValue[0]){
        this.bindData[this.insuredIndex].elementOpenDTOList = [this.bindData[this.insuredIndex].elementOpenDTOList[0]];
      }else if(this.bindData[this.insuredIndex].elementOpenDTOList.length == 1){
        this.bindData[this.insuredIndex].elementOpenDTOList.push(...this.insuredElements);
      }
    },
    // 记录城市列表值
    cityNameChange(ids,names){
      // console.info("城市值：",ids, names);
      this.cityNames = names;
    },
    // 返回校验警告信息
    getAlertMsg(moduleName,elementName){
      return `请输入正确的${moduleName}【${elementName}】`;
    },
    getModuleNameForAlert(moduleName){
      if(!!moduleName) return moduleName.substr(0, moduleName.indexOf("人")+1);
      return "";
    }
  },
  mounted(){
    let userCommitData = this.$store.getters['policyWrite/getPolicyWriteData'];
    console.info("store bindData", userCommitData);
    if (null == userCommitData || !Array.isArray(userCommitData) || userCommitData.length == 0) {//DELETE /cms/product/policyElemenets/{productId}/{queryType}
      this.$http.get('/api/p_front/cms/product/policyElemenets/'+this.$route.params.productId+'/01').then(response => {
        this.policyTemplateEle = response.data.templetOpenDTO;
        // 字符串 对象转换
        this.stringToArray(this.policyTemplateEle.moduleOpenDTOList);
        this.bindData = this.policyTemplateEle.moduleOpenDTOList;
      })
    } else {
       this.bindData = userCommitData;
    }
    this.getElementsMatch();
  },
  //计算属性绑定
  computed: {
    // reservmessage: function(){
    //   console.log("计算属性绑定:"+this.holderNameValue);
    // },
    produceSubmitButtonValue(){

    }
  },
  watch: {
    bindData:{
      deep: true, //深度监听
      handler: function (newVal,oldVal) {
        /*console.log(newVal[0].elementOpenDTOList[0].elementFieldId);
        console.log(newVal+"==="+oldVal)*/
      }
    }
  },
  data () {
    return {
      holderCardTypeValue:['1'],
      submitButtonValue: '投保预览',
      cityPicker:ChinaAddressData,
      holderSexData:[{name:'123',value:'1'},{name:'1234',value:'11'}],
      bindData:[],
      policyCommitMatch:{},
      cityCode:[],
      showPositionValue:false,
      alertContent:'validate failed',
      position:'middle',
      defaultYear:1900,
      insuredIndex:-1,
      insuredElements:[],
      cityNames:["山西省", "阳泉市", "郊区"]
    }
  }
}
</script>
<style lang="less">
  .weui-cells {
    font-size: 15px !important;
    padding: 8px 15px !important;
    .vux-cell-primary {
        -webkit-box-flex: 1;
        -ms-flex: 1;
        flex: 1;
    }

    .weui-label{

      //width:5rem !important;
    }
  }
  .cell_bottom{
    border-bottom:1px solid #e8e8ea;
  }
</style>
<style lang="less" scoped>
  @import '~vux/src/styles/1px.less';
  @import '~vux/src/styles/center.less';

</style>

