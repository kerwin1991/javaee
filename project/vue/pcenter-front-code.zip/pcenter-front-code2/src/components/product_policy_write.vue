<template>
<div >
    <x-header :left-options="{backText: ''}">华华惠满家综合保障计划</x-header>
    <group class="policy_write_group" title-color="#43b0f1" title="投保人信息" label-width="5em" label-margin-right="1em" label-align="left">
        <x-input title="姓&emsp;&emsp;&nbsp;名" v-model="holderNameValue" placeholder='请输入姓名' placeholder-align='left' ></x-input>
        <popup-picker title="证件类型" :columns="1" :data="holderCardTypeList" v-model="holderCardTypeValue" :placeholder="'请选择证件类型'" value-text-align="left" show-name></popup-picker>
        <x-input title="证件号码" v-model="holderCardNoValue" placeholder='请输入证件号码' placeholder-align='left' ></x-input>
        <datetime title="出生日期" v-model="holderBirthValue" value-text-align="left" placeholder="请输入出生日期"></datetime>
        <popup-picker title="性&emsp;&emsp;&nbsp;别" :columns="1" placeholder="请输入性别" :data="holderSexList" v-model="holderSexValue" value-text-align="left" show-name></popup-picker>
        <x-input title="手机号码" type="tel" v-model="holderTelValue" placeholder='请输入手机号码' placeholder-align='left' ></x-input>
        <x-input title="邮&emsp;&emsp;&nbsp;箱" type="email" v-model="holderEmailValue" placeholder='请输入邮箱' placeholder-align='left' ></x-input>
    </group>
    <group title-color="#43b0f1" title="与被保人信息" label-width="5em" label-margin-right="1em" label-align="left">    
        <popup-picker title="投保人关系" :columns="1" :data="holderRelationList" v-model="holderRelationValue" :placeholder="'请选择证件类型'" value-text-align="left" show-name></popup-picker>
        <x-input title="证件号码" v-model="holderCardNoValue" placeholder='请输入证件号码' placeholder-align='left' ></x-input>
        <datetime title="出生日期" v-model="holderBirthValue" value-text-align="left" placeholder="请输入出生日期"></datetime>
        <!-- <popup-picker title="性&emsp;&emsp;&nbsp;别" placeholder="请输入性别" :data="[['男','女']]" v-model="holderSexValue" value-text-align="center" ></popup-picker> -->
        <x-input title="手机号码" type="tel" v-model="holderTelValue" placeholder='请输入手机号码' placeholder-align='left' ></x-input>
        <x-input title="邮&emsp;&emsp;&nbsp;箱" type="email" v-model="holderEmailValue" placeholder='请输入邮箱' placeholder-align='left' ></x-input>
    </group>
     <group title-color="#43b0f1" title="受益人信息" label-width="6em" label-margin-right="1em" label-align="left">    
         <x-input title="受益人" value="法定" placeholder-align='left' readonly ></x-input>
    </group>
    <group title-color="#43b0f1" title="房屋信息" label-width="6em" label-margin-right="1em" label-align="left">    
        <x-address title="所在城市" raw-value :list="houseAddressList" value-text-align="left" label-align="justify"></x-address>
        <x-input title="详细地址" v-model="holderNameValue" placeholder='需要精确到门牌号,请如实填写' placeholder-align='left' ></x-input>
        <popup-picker title="房屋结构" :columns="1" :data="houseStructureList" v-model="houseStructureValue" :placeholder="'请选择房屋结构'" value-text-align="left" show-name></popup-picker>
    </group>
    <x-button :text="submitButtonValue"  @click.native="processButton001" type="primary"></x-button>
    <div>{{reservmessage}}</div>
</div>
</template>
<script>
import { XButton, XHeader, GroupTitle, Group, Cell, XInput, Selector, PopupPicker, Datetime, XNumber, ChinaAddressData, XAddress, XTextarea, XSwitch } from 'vux'

const holderSexList = 
   [
      {
        name: '男',
        value: '0'
      }, 
      {
        name: '女',
        value: '1'
      }
    ]
const holderCardTypeList = 
   [
      {
        name: '身份证',
        value: '0'
      }, 
      {
        name: '户口本',
        value: '1'
      }
   ]
const holderRelationList = 
   [
      {
        name: '本人',
        value: '0'
      }, 
      {
        name: '父母',
        value: '1'
      }
   ]
const houseStructureList =
  [
      {
        name: '钢筋混凝土结构',
        value: '0'
      }, 
      {
        name: '钢结构',
        value: '1'
      }, 
      {
        name: '混合结构',
        value: '2'
      }
   ]
export default {
  components: {
    XButton,XHeader,GroupTitle,Group,Cell,XInput,Selector,PopupPicker,Datetime,XNumber,
    ChinaAddressData,XAddress,XTextarea,XSwitch
  },
  methods:{
   
  },
  mounted(){
      console.log("===="+JSON.stringify(this.$store.state.productDetail.product));
  },
  //计算属性绑定
  computed: {
    reservmessage: function(){
      console.log("计算属性绑定:"+this.holderNameValue);
    },
    produceSubmitButtonValue(){

    }
  },
  data () {
    return {
      submitButtonValue: '投保预览',
      houseAddressList: ChinaAddressData,
      demo01_list: 1236,
      holderNameValue: '',
      holderCardTypeList: holderCardTypeList,
      holderCardTypeValue:['1'],
      holderCardNoValue:'',
      holderBirthValue:'',
      holderSexList: holderSexList,
      holderSexValue: [],
      holderTelValue: '',
      holderEmailValue: '',
      houseStructureList: houseStructureList,
      houseStructureValue:['0'],
      holderRelationList: holderRelationList,
      holderRelationValue:[]


    }
  }
}
</script>
<style lang="less">
  .weui-cells {
    font-size: 15px !important;
    padding: 8px 15px !important;
  }
</style>
<style lang="less" scoped>
  @import '~vux/src/styles/1px.less';
  @import '~vux/src/styles/center.less';
 
</style>

