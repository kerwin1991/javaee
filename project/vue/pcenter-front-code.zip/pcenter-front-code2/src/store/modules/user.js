export default {
  namespaced: true,//定义数据
  //==>定义数据
  state: {
    user:{}
  },
  //定义具体属性的get方法
  getters: {
    loading: function(state){
      state.loading = true;
    }
  },
  //==>操作数据
  mutations: {
    setState (state, payload) {
      for (let key in payload) {
        state[key] = payload[key]
      }
    },
    setHolder(state,holderDTO) {
      console.log("setHolder in productDetail.js is running ...");
    }
  },
  actions: {
    setState ({commit}, data) {
      commit('setState', data)
    }
  }
}