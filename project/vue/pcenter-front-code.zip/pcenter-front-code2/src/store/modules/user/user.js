import Cookies from 'js-cookie'

export default {
  namespaced: true,//定义数据
  //==>定义数据
  state: {
    uid: '',
    name: '',
    token: '',
    role: '',
    avatar: ''
  },
  //定义具体属性的get方法
  getters: {
    loading: function(state){
      state.loading = true;
    }
  },
  //==>操作数据
  mutations: {
    setUID (state, data) {
        console.log("setUID"+data);
    }
  },
  actions: {
    setState ({commit}, data) {
      commit('setState', data)
    }
  }
}