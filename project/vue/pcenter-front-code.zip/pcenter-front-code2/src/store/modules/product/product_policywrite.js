export default {
  namespaced: true,//定义数据
  //==>定义数据
  state: {
    product:{"name":"123"}
  },
  //定义具体属性的get方法
  getters: {
    getProduct(state) {
      return state.product;
    },
    getPolicyWriteData(state){
      return JSON.parse(localStorage.getItem("policyWriteData"));
    }
  },
  mutations: {
    setProduct (state,newData) {
      state.product = newData ;
    },
    storePolicyWriteData(state,policyWriteData){
      localStorage.setItem("policyWriteData", JSON.stringify(policyWriteData));
    },
    removePolicyWriteData(state,policyWriteData){
      localStorage.removeItem("policyWriteData");
    }
  },
  actions: {
    setState ({commit}) {
      commit('setState')
    }
  }
}
