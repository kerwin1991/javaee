export default {
  namespaced: true,//定义数据
  //==>定义数据
  state: {
    price: 100,
    loading: false,
    page: 1,
    no_more: false,
    load_err: false,
    load_more_tip: '别拉了，到底了',
    init: false,
    page_show: false,
    swiper_list: [],
    rec_hot: [],
    holder: {},
    calculateElements:[],
    listSku:[],
    calculateData:{},
    prenium:'',
    product:{"name":"123"},
    coreProduct:{productId:"",skucode:"1711280010102"},
    orderInfos:{orderId:"b7269100415a41e4867ceca2bf765225",policyId:"6c650b96faeb4148842b294794023bb5"},
    commitData:[]
  },
  //定义具体属性的get方法
  getters: {
    loading: function(state){
      state.loading = true;
    },
    /*setListSku:function(state,listSku){
      this.listSku=listSku;
    },*/
    setCalculateData(){

    },
    getProduct(state) {
      // console.log("get:"+sessionStorage.getItem("front_product_info"));
      // return JSON.parse(sessionStorage.getItem("front_product_info"));
      return state.product;
    },
    getSkucode(state){
      return state.coreProduct.skucode;
    },
    getPolicyId(state){
      return state.orderInfos.policyId;
    }
  },
  mutations: {
    setProduct (state,newData) {
      // console.log("set:"+JSON.stringify(newData));
      // sessionStorage.setItem("front_product_info", JSON.stringify(newData));
      state.product = newData ;
    },
    setCoreProduct (state,data) {
      state.coreProduct.productId = data.productId;
      state.coreProduct.skucode = data.skucode;
    },
    setOrderInfos(state,newDate) {
      state.orderInfos.orderId = newDate.orderId;
      state.orderInfos.policyId = newDate.policyId;
    },
    setCommitData(state,newDate){
      state.commitData = newDate;
    }
  },
  actions: {
    setState ({commit}) {
      commit('setState')
    }
  }
}
