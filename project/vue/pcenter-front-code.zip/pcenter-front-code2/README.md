项目执行步骤：

第一步
npm install

第二步
npm run dev

