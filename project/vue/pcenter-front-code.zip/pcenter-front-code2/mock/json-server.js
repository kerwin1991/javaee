const jsonServer = require('json-server')
const server = jsonServer.create()

// Support middleware
const middleware = jsonServer.defaults()
server.use(middleware)

// 支持加载多个db json文件
const _ = require('underscore')
const path = require('path')
const fs = require('fs')
const mockDir = path.join(__dirname, '')
const base = {}
const files = fs.readdirSync(mockDir)
files.forEach(function (file) {
  _.extend(base, require(path.resolve(mockDir, file)))
})
const router = jsonServer.router(base)

// 路由规则要在 server.use(router)之前添加
server.use(jsonServer.rewriter({
  '/cms/product/policyEles': '/policyElements',
  '/cms/product/getCmsProduct/:productId': '/productdetail',
  '/product/calelements/:productId': '/productcalelemenst',
  '/product/prenium/:productId': '/productprenium',

  '/blog/:resource/:id/show': '/:resource/:id',
  '/product/policy/preview': '/policyReviewShow',
  '/product/policy/query': '/productQuery',
}))
// 在JSON Server router之前添加自定义路由
server.get('/echo', (req, res) => {
  res.jsonp(req.query)
})
server.use((req, res, next) => {
  // if (req.method === 'POST') {

  //   req.body.createdAt = Date.now()
  // }
  // 继续json-server路由
  next()
})

server.use(router)

// 返回自定义格式数据
// router.render = (req, res) => {
//   res.jsonp({
//     data: res.locals.data,
//     status: 0,
//     msg: ''
//   })
// }

server.listen(9090, () => {
  console.log('JSON Server is running')
})
